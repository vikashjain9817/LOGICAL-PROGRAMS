package DateTesting;

class Date
{
	int Day;
	int Month;
	int Year;
	// Constructor
	Date(int Day, int Month, int Year) throws DayIsNotValidException {
		if(Day == 0  || Day  > 31)
			throw new DayIsNotValidException();
		this.Day = Day;
		this.Month = Month;
		this.Year = Year;
	}
	// setter and getter methods
	void setDay(int Day)
	{
		this.Day = Day;
	}
	int getDay( )
	{
		return this.Day;
	}
	void setMonth(int Month)
	{
		this.Month = Month;
	}
	int getMonth( )
	{
	return this.Month;
	}
	void setYear(int Year)
	{
	this.Year=Year;
	}
	int getYear( )
	{
		return this.Year;
	}
	@Override
	public String toString() {
		return "Date [Day=" + Day + ", Month=" + Month + ", Year=" + Year + "]";
	}
	
	
}