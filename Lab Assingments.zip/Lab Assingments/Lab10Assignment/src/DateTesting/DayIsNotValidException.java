package DateTesting;

public class DayIsNotValidException extends Exception {

}
