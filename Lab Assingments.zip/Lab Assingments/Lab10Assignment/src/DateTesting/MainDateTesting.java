package DateTesting;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MainDateTesting {
	
	@Test
	public void WhenTheDateIsGivenThenTheDateIsVarifiedSuccesfully() throws DayIsNotValidException {
		Date date = new Date(02,12,2019);
		assertEquals(02, date.getDay());
	}
	
	@Test
	public void WhenTheDateIsGivenThenTheMonthIsVarifiedSuccesfully() throws DayIsNotValidException {
		Date date = new Date(02,12,2019);
		assertEquals(12, date.getMonth());
	}
	
	
	@Test
	public void WhenTheDateIsGivenThenTheYearIsVarifiedSuccesfully() throws DayIsNotValidException {
		Date date = new Date(02,12,2019);
		assertEquals(2019, date.getYear());
	}
	

	@Test(expected = DateTesting.DayIsNotValidException.class )
	public void WhenTheDayIsNotGivenThenThrowAnException() throws DayIsNotValidException {
		Date date = new Date(32,12,2019);
	}

}
