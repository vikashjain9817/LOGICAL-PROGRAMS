package Lab11Fifth;

public interface IFactorial {
	public void fact();
}
