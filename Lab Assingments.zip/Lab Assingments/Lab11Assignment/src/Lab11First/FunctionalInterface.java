package Lab11First;


public @interface FunctionalInterface {

}
