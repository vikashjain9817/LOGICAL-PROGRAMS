package Lab11First;

public interface PowerInterface {

	public double power(double x, double y);
	
}