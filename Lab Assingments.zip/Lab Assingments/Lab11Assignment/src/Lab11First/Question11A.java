package Lab11First;


public abstract class Question11A implements  PowerInterface {
	public static void main(String[] args) {
		PowerInterface p =(double x, double y)->{double m=Math.pow(x,y); System.out.println(m); return m;};
		p.power(2.0,2.0);
		
	}

}