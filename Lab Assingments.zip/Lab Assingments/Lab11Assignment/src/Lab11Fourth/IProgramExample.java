package Lab11Fourth;

public interface IProgramExample {

	Simple methodDemo();

}
