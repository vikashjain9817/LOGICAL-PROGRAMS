package Lab11Second;


public abstract class CreateSpaceInAString implements IStringSpace {
    public static void main(String[] args) {
	 
    	IStringSpace e = (String)->{ System.out.println(String.replace(""," "));};
    	e.space("hai");
}
    
}