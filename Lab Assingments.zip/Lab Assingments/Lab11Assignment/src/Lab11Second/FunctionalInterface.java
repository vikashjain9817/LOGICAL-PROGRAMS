package Lab11Second;

public @interface FunctionalInterface {

}
