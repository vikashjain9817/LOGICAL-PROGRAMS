package Lab11Second;

public interface IStringSpace {

	void space(String string);
	
}
