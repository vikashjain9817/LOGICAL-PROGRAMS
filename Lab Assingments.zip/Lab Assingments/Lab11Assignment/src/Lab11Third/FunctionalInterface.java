package Lab11Third;

public @interface FunctionalInterface {

}

