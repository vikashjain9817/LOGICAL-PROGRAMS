package Lab11Third;

public interface ILoginOperation {

	boolean login(String string, String string2);
	
}
