public class Question2B {
	 int n;
	 public  void check(){
		 if(n>0)
		 {
			 System.out.println("positive number");
		 }
		 else
		 {
			 System.out.println("negative no");
		 }

	 }
	public static void main(String[] args) {
		Question2B obj= new Question2B();
		int N= Integer.parseInt(args[0]);
		obj.n=N;
		obj.check();
	}
}
