package com.capgemini.view;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class DiffBetweenTwoDates {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		   System.out.println("enter 1st day");
		    int d1 = sc.nextInt();
		    System.out.println("enter 1st month");
		    int m1 = sc.nextInt();
		    System.out.println("enter 1st year");
		    int y1 = sc.nextInt();
		    
		    System.out.println("enter 2nd day");
		    int d2 = sc.nextInt();
		    System.out.println("enter 2nd month");
		    int m2 = sc.nextInt();
		    System.out.println("enter 2nd year");
		    int y2 = sc.nextInt();
		    
	        LocalDate pdate = LocalDate.of(y1,m1,d1);
	        LocalDate now = LocalDate.of(y2,m2,d2);
	 
	        Period diff = Period.between(pdate, now);
	 
	     System.out.printf("\nDifference is %d years, %d months and %d days old\n\n", 
	                    diff.getYears(), diff.getMonths(), diff.getDays());

	}

}
