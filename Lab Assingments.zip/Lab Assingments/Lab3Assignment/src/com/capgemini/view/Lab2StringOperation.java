package com.capgemini.view;

import java.util.LinkedHashSet;
import java.util.Scanner;

public class Lab2StringOperation {
	
	public static String stringOperation(String s, int option)
	{
		char s1[] = s.toCharArray();
		
		
		if(option == 1)
		{
			return s+s;
		}
		
		
		if(option == 2)
		{
			for(int  i = 0; i < s.length(); i+=2)
			{
				s1[i] = '#';
			}
			return new String(s1);
		}
		
		
		if(option == 3)
		{
			LinkedHashSet<Character> lhs = new LinkedHashSet<>(); 
	        for(int i=0;i<s.length();i++) 
	            lhs.add(s.charAt(i)); 
	        for(Character ch : lhs) 
	        		System.out.print(ch); 
		}
		
		
		if(option == 4)
		{
			for(int  i = 0; i < s.length(); i+=2)
			{
				if(s1[i] >= 97 || s1[i] <= 122)
				{
					s1[i] = (char) (s1[i]-32);
				}
			}
			return new String(s1);
		}
		return "";
		
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter string");
		String s = sc.next();
		System.out.println("1 for ADD string to itself, 2 for replace odd position with #, 3 for remove duplicate charcter from String, 4 for Change odd charcter to upper case");
		int n = sc.nextInt();
		System.out.println(stringOperation(s, n));
	}

}
