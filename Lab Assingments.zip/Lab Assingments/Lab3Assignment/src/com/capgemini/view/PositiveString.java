package com.capgemini.view;

import java.util.Arrays;
import java.util.Scanner;

public class PositiveString {

	public static boolean checkPositiveString(String s)
	{
		char [] s1 = s.toLowerCase().toCharArray();
		char [] s2 = s.toLowerCase().toCharArray();
		Arrays.sort(s2);
		if(Arrays.equals(s1,s2))
			return true;
		else
			return false;
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter string");
		String s = sc.next();
		if(checkPositiveString(s))
			System.out.println("positive string");
		else
			System.out.println("not positive string");

	}

}
