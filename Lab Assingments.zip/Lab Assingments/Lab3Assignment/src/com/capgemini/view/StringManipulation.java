package com.capgemini.view;

import java.util.Arrays;
import java.util.Scanner;

public class StringManipulation {

	public static String[] stringManipulation(String[] s)
	{
		
		Arrays.sort(s);
		int  l = s.length;
		if(l % 2 == 0)
		{
			l = l / 2;
			for(int  i = 0; i < l; i++ ) {
				s[i] = s[i].toUpperCase();
			}
			for(int i = l; i < s.length; i++) {
				s[i] = s[i].toLowerCase();
			}
			return s;
		}
		else
		{
			l = (l/2) + 1;
			for(int  i = 0; i < l; i++ ) {
				s[i] = s[i].toUpperCase();
			}
			for(int i = l; i < s.length; i++) {
				s[i] = s[i].toLowerCase();
			}
			return s;
		}
		
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number of string");
		int n = sc.nextInt();
		String [] s = new String[n];
		System.out.println("enter the " + n + " Strings");
		for(int i = 0; i < n; i++)
		{
			s[i] = sc.next();
		}
		String [] result = stringManipulation(s);
		for(int i = 0;  i < result.length; i++)
		{
			System.out.println(result[i]);
		}
	}

}
