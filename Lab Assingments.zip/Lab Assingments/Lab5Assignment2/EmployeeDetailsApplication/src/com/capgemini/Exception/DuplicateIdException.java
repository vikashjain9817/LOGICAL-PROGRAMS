package com.capgemini.Exception;

public class DuplicateIdException extends Exception {

}
