package com.capgemini.exception;

public class InsufficientOpeningBalanceException extends Exception {

}
