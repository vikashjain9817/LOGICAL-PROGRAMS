package com.capgemini.exception;

public class InvalidAccountNumberException extends Exception {

}
