package com.capgemini.beans;

public class NameException extends Exception {

	String fname;
	String lname;
	public NameException(String fname, String lname) {
		super();
		this.fname = fname;
		this.lname = lname;
	}
	@Override
	public String toString() {
		return "nameException [fname=" + fname + ", lname=" + lname + "]";
	}
}
