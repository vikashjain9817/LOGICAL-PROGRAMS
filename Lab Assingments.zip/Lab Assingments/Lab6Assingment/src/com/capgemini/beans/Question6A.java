package com.capgemini.beans;



import java.util.Scanner;

public class Question6A {
	private String fname;
	private String lname;
	
	public Question6A(String fname, String lname) {
		this.fname= fname;
		this.lname= lname;
	}
	
	public void method()throws NameException
	{
		if(fname.equals("")&& lname.equals(""))
	{
		throw new NameException("name is not correct","lname is not correct");
	}
	else
		System.out.println("full name is correct");
	}

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("enter first name");
		String str= sc.nextLine();
		System.out.println("enter last name");
		String str2 = sc.nextLine();
		Question6A obj= new Question6A(str,str2);
		
		
		try{
		obj.method();
		}
		catch ( NameException e)
		{
			System.out.println(e);
			System.out.println(e.getMessage());
		}
		
	}

	}
